﻿using CommunityToolkit.Mvvm.ComponentModel;
using CTSliceAnalyzer.Model;
using System.Collections.ObjectModel;

namespace CTSliceAnalyzer.ViewModel;

/// <summary>
/// Represents a ViewModel for a CT slices report, encompassing global minimum and maximum slice values,
/// an average value, and a collection of individual slices.
/// </summary>
public partial class ReportViewModel : ObservableObject
{
    /// <summary>
    /// The underlying <see cref="Report"/> model that this ViewModel represents.
    /// </summary>
    private readonly Report _report;

    /// <summary>
    /// Gets or sets a ViewModel representing the global minimum value across all slices.
    /// </summary>
    [ObservableProperty]
    private GlobalValueViewModel? _globalMinValue;

    /// <summary>
    /// Gets or sets a ViewModel representing the global maximum value across all slices.
    /// </summary>
    [ObservableProperty]
    private GlobalValueViewModel? _globalMaxValue;

    /// <summary>
    /// Gets or sets the global average value across all slices.
    /// </summary>
    [ObservableProperty]
    private double? _globalAvgValue;

    /// <summary>
    /// Gets the observable collection of slice ViewModels.
    /// </summary>
    public ObservableCollection<SliceViewModel> Slices { get; set; } = new();

    /// <summary>
    /// Gets the underlying <see cref="Report"/> model.
    /// </summary>
    public Report Model => _report;

    /// <summary>
    /// Initializes a new instance of the <see cref="ReportViewModel"/> class with the specified <see cref="Report"/>.
    /// Synchronizes global min, max, and average values, and initializes the <see cref="Slices"/> collection.
    /// </summary>
    /// <param name="report">The <see cref="Report"/> model to be represented by this ViewModel.</param>
    public ReportViewModel(Report report)
    {
        _report = report;

        GlobalMinValue = new GlobalValueViewModel(report.GlobalMinValue);
        GlobalMaxValue = new GlobalValueViewModel(report.GlobalMaxValue);
        GlobalAvgValue = report.GlobalAvgValue;

        foreach (var slice in report.Slices)
        {
            Slices.Add(new SliceViewModel(slice));
        }

        report.Update = () =>
        {
            GlobalAvgValue = report.GlobalAvgValue;
        };
    }

    /// <summary>
    /// Adds a slice to both the underlying report model and the <see cref="Slices"/> collection.
    /// </summary>
    /// <param name="slice">The slice to be added.</param>
    public void AddSlice(Slice slice)
    {
        _report.Slices.Add(slice);
        Slices.Add(new SliceViewModel(slice));
    }
}
