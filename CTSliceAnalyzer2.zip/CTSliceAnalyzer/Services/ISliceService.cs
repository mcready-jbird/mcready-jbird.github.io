﻿using CTSliceAnalyzer.Model;

namespace CTSliceAnalyzer.Services;

/// <summary>
/// Defines methods for loading and processing CT slices, raising events when slices
/// are successfully loaded or processed.
/// </summary>
public interface ISliceService
{
    /// <summary>
    /// Occurs when a slice has been successfully loaded from a file.
    /// </summary>
    event Action<Slice> Loaded;

    /// <summary>
    /// Occurs when a slice has been successfully processed to compute min, max, and average values.
    /// </summary>
    event Action<Slice> Processed;

    /// <summary>
    /// Asynchronously loads slices from the specified collection of file names.
    /// </summary>
    /// <param name="fileNames">The collection of slice file names to load.</param>
    /// <param name="cancellationToken">
    /// A token that can be used to cancel the load operation.
    /// </param>
    Task LoadSlices(IEnumerable<string> fileNames, CancellationToken cancellationToken);

    /// <summary>
    /// Asynchronously processes the slices in the provided <see cref="Report"/>, computing their min, max, and average values.
    /// For each processed slice, the <see cref="Processed"/> event is raised.
    /// </summary>
    /// <param name="report">The <see cref="Report"/> that holds the slices to be processed.</param>
    /// <param name="cancellationToken">
    /// A token that can be used to cancel the processing operation.
    /// </param>
    Task ProcessSlices(Report report, CancellationToken cancellationToken);
}
