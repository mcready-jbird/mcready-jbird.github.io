﻿using CTSliceAnalyzer.Global;
using CTSliceAnalyzer.Model;
using Microsoft.Extensions.Primitives;
using System.IO;

namespace CTSliceAnalyzer.Services;

/// <summary>
/// Provides functionality for loading and processing CT slices from text files.
/// Implements the <see cref="ISliceService"/> interface, raising events when slices
/// are successfully loaded or processed.
/// </summary>
public class SliceService : ISliceService
{
    /// <summary>
    /// Occurs when a slice has been successfully loaded from a file.
    /// </summary>
    public event Action<Slice>? Loaded;

    /// <summary>
    /// Occurs when a slice has been successfully processed (min, max, average computed).
    /// </summary>
    public event Action<Slice>? Processed;

    /// <summary>
    /// Asynchronously loads slices from the specified collection of file names.
    /// Each file is read to extract its Z-position, dimensions, and raw data.
    /// For each successfully loaded slice, the <see cref="Loaded"/> event is raised.
    /// </summary>
    /// <param name="fileNames">The collection of slice file names to load.</param>
    /// <param name="cancellationToken">A token that can be used to cancel the load operation.</param>
    /// <exception cref="OperationCanceledException">Thrown when the operation is canceled.</exception>
    /// <exception cref="Exception">Thrown if an error occurs while reading or parsing file data.</exception>
    public async Task LoadSlices(IEnumerable<string> fileNames, CancellationToken cancellationToken)
    {
        foreach (var fileName in fileNames)
        {
            try
            {
                cancellationToken.ThrowIfCancellationRequested();
                using var reader = new StreamReader(fileName);

                // Read the Z-position of the slice
                var zPositionString = await reader.ReadLineAsync(cancellationToken);
                if (!double.TryParse(zPositionString, NumberFormatSettings.NumberFormatInfo, out double zPosition))
                {
                    throw new Exception("Incorrect Z position");
                }

                // Read and parse slice dimensions
                var dimensionString = await reader.ReadLineAsync(cancellationToken);
                var dimensions = dimensionString?.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (dimensions?.Length != 2)
                {
                    throw new Exception("Incorrect dimensions");
                }
                if (!int.TryParse(dimensions[0], out var width))
                {
                    throw new Exception("Incorrect width");
                }
                if (!int.TryParse(dimensions[1], out var height))
                {
                    throw new Exception("Incorrect height");
                }

                // Read raw data (values)
                var rawData = await reader.ReadLineAsync(cancellationToken);
                if (string.IsNullOrEmpty(rawData))
                {
                    throw new Exception("No values found");
                }

                var slice = new Slice
                {
                    FileName = fileName,
                    RawData = rawData,
                    ZPosition = Math.Round(zPosition, 12),
                    Dimensions = new Dimensions(width, height)
                };

                // Raise the Loaded event for this slice
                Loaded?.Invoke(slice);
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error loading file {fileName}", ex);
            }
        }
    }

    /// <summary>
    /// Asynchronously processes each slice in the given <see cref="Report"/> to compute its minimum, maximum, and average intensity values. 
    /// The <see cref="Processed"/> event is raised for each slice upon successful completion.
    /// </summary>
    /// <param name="report">The <see cref="Report"/> containing slices to be processed.</param>
    /// <param name="cancellationToken">A token that can be used to cancel the processing operation.</param>
    /// <exception cref="OperationCanceledException">Thrown when the operation is canceled.</exception>
    public async Task ProcessSlices(Report report, CancellationToken cancellationToken)
    {
        var options = new ParallelOptions
        {
            MaxDegreeOfParallelism = Environment.ProcessorCount,
            CancellationToken = cancellationToken
        };

        // Use parallel processing to handle each slice
        await Parallel.ForEachAsync(report.Slices, options, ProcessSlice);
    }

    /// <summary>
    /// Processes a single slice, parsing its raw data to determine the slice's minimum, maximum, and average intensity values. Raises the <see cref="Processed"/> event.
    /// </summary>
    /// <param name="slice">The slice to process.</param>
    /// <param name="cancellationToken">A token that can be used to cancel the operation.</param>
    /// <exception cref="OperationCanceledException">Thrown when the operation is canceled.</exception>
    /// <exception cref="Exception">Thrown if the raw data is missing or if there are parsing errors.</exception>
    private ValueTask ProcessSlice(Slice slice, CancellationToken cancellationToken)
    {
        try
        {
            if (slice.RawData == null)
            {
                return ValueTask.CompletedTask;
            }

            // Tokenize raw data to iterate through values
            var tokenizer = new StringTokenizer(slice.RawData, new[] { ' ' });

            int totalValues = slice.Dimensions.Width * slice.Dimensions.Height;

            var minValue = new SliceValue(int.MaxValue);
            var maxValue = new SliceValue(int.MinValue);
            double avgValue = 0.0;

            int index = 0;
            foreach (var token in tokenizer)
            {
                cancellationToken.ThrowIfCancellationRequested();

                if (!int.TryParse(token.ToString(), out int value))
                {
                    throw new Exception($"Incorrect value ({token})");
                }

                if (value < minValue.Value)
                {
                    minValue = new SliceValue(value, index % slice.Dimensions.Width, index / slice.Dimensions.Width);
                }

                if (value > maxValue.Value)
                {
                    maxValue = new SliceValue(value, index % slice.Dimensions.Width, index / slice.Dimensions.Width);
                }

                avgValue += (double)value / totalValues;
                index++;
            }

            if (index != totalValues)
            {
                throw new Exception($"Incorrect amount of values {index} instead of {totalValues}");
            }

            slice.MinValue = minValue;
            slice.MaxValue = maxValue;
            slice.AvgValue = avgValue;

            // Raise the Processed event for this slice
            Processed?.Invoke(slice);

            return ValueTask.CompletedTask;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error processing slice {slice.FileName}", ex);
        }
    }
}
