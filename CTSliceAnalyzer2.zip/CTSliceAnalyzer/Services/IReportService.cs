﻿using CTSliceAnalyzer.Model;

namespace CTSliceAnalyzer.Services;

/// <summary>
/// Defines methods for loading and saving <see cref="Report"/> objects to and from persistent storage.
/// </summary>
public interface IReportService
{
    /// <summary>
    /// Asynchronously loads a <see cref="Report"/> from the specified file path.
    /// </summary>
    /// <param name="filePath">The path of the file containing the saved report data.</param>
    /// <param name="cancellationToken">A token to cancel the load operation.</param>
    /// <returns>A task representing the asynchronous load operation, returning the loaded <see cref="Report"/>.</returns>
    Task<Report> LoadReport(string filePath, CancellationToken cancellationToken);

    /// <summary>
    /// Asynchronously saves the specified <see cref="Report"/> to a file at the given path.
    /// </summary>
    /// <param name="filePath">The path of the file to write the report data to.</param>
    /// <param name="report">The <see cref="Report"/> to serialize and save.</param>
    /// <param name="cancellationToken">A token to cancel the save operation.</param>
    Task SaveReport(string filePath, Report report, CancellationToken cancellationToken);
}
