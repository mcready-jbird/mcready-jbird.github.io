﻿using CTSliceAnalyzer.Model;
using System.IO;
using System.Text.Json;

namespace CTSliceAnalyzer.Services;

/// <summary>
/// Provides functionality for loading and saving CT slice reports as JSON files,
/// implementing the <see cref="IReportService"/> interface.
/// </summary>
public class ReportService : IReportService
{
    /// <summary>
    /// Asynchronously loads a <see cref="Report"/> object from a JSON file.
    /// </summary>
    /// <param name="filePath">The path of the JSON file to read.</param>
    /// <param name="cancellationToken">A token that can be used to cancel the operation.</param>
    /// <returns>
    /// The task result that contains the deserialized <see cref="Report"/> object.
    /// </returns>
    /// <exception cref="OperationCanceledException">Thrown if the operation is canceled.</exception>
    /// <exception cref="Exception">Thrown if an error occurs during file I/O or JSON deserialization.</exception>
    public async Task<Report> LoadReport(string filePath, CancellationToken cancellationToken)
    {
        try
        {
            string json = await File.ReadAllTextAsync(filePath, cancellationToken);
            var report = JsonSerializer.Deserialize<Report>(json);

            if (report == null)
            {
                throw new Exception("Error deserializing JSON: the report is null.");
            }

            return report;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error loading report from {filePath}", ex);
        }
    }

    /// <summary>
    /// Asynchronously saves a <see cref="Report"/> object to a JSON file.
    /// </summary>
    /// <param name="filePath">The path of the JSON file to write.</param>
    /// <param name="report">The <see cref="Report"/> object to serialize.</param>
    /// <param name="cancellationToken">A token that can be used to cancel the operation.</param>
    /// <exception cref="OperationCanceledException">
    /// Thrown if the operation is canceled. If a file was partially written, it is deleted.
    /// </exception>
    /// <exception cref="Exception">Thrown if an error occurs during file I/O or JSON serialization.</exception>
    public async Task SaveReport(string filePath, Report report, CancellationToken cancellationToken)
    {
        try
        {
            string json = JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true });
            await File.WriteAllTextAsync(filePath, json, cancellationToken);
        }
        catch (OperationCanceledException)
        {
            // Attempt to delete the partially written file
            try
            {
                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }
            }
            catch
            {
            }

            throw;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error saving report to {filePath}", ex);
        }
    }
}
