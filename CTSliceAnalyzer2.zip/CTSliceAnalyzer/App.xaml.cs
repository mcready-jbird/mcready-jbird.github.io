﻿using CTSliceAnalyzer.Services;
using CTSliceAnalyzer.View;
using CTSliceAnalyzer.ViewModel;
using Microsoft.Extensions.DependencyInjection;
using System.Windows;

namespace CTSliceAnalyzer;

public partial class App : Application
{

    private IServiceProvider? _serviceProvider;

    protected override void OnStartup(StartupEventArgs e)
    {
        var serviceCollection = new ServiceCollection();
        ConfigureServices(serviceCollection);

        _serviceProvider = serviceCollection.BuildServiceProvider();

        var mainWindow = _serviceProvider.GetRequiredService<MainWindow>();
        mainWindow.Show();
    }

    private void ConfigureServices(IServiceCollection services)
    {
        services.AddSingleton<MainWindow>();
        services.AddSingleton<MainViewModel>();
        services.AddSingleton<ISliceService, SliceService>();
        services.AddSingleton<IReportService, ReportService>();
    }

    private void OnExit(object sender, ExitEventArgs e)
    {
        if (_serviceProvider is IDisposable disposable)
        {
            disposable.Dispose();
        }
    }
}
