﻿using CTSliceAnalyzer.Global;
using System.Text.Json.Serialization;

namespace CTSliceAnalyzer.Model;

/// <summary>
/// Represents a report containing global statistics (minimum, maximum, and average values) for a set of CT slices, as well as a collection of them.
/// </summary>
public class Report
{
    /// <summary>
    /// Delegate that can be invoked to notify ViewModel of changes within this report.
    /// </summary>
    public Action? Update;

    /// <summary>
    /// Gets or sets the global minimum value found across all slices.
    /// </summary>
    [JsonPropertyName("global_min")]
    public GlobalValue GlobalMinValue { get; set; } = new GlobalValue();

    /// <summary>
    /// Gets or sets the global maximum value found across all slices.
    /// </summary>
    [JsonPropertyName("global_max")]
    public GlobalValue GlobalMaxValue { get; set; } = new GlobalValue();

    /// <summary>
    /// Gets or sets the global average value computed across all slices.
    /// </summary>
    [JsonPropertyName("global_avg")]
    public double? GlobalAvgValue { get; set; }

    /// <summary>
    /// Gets or sets the list of slices within this report.
    /// </summary>
    [JsonPropertyName("slices")]
    public List<Slice> Slices { get; set; } = new();

    /// <summary>
    /// Invokes the <see cref="Update"/> action to notify listeners that the report's data has changed.
    /// </summary>
    public void InvokeUpdate()
    {
        Update?.Invoke();
    }
}
