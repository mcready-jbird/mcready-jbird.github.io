﻿using System.Text.Json.Serialization;

namespace CTSliceAnalyzer.Model;

/// <summary>
/// Represents a global value within a CT scan, used for recording the position (Z) and an associated value.
/// </summary>
public class GlobalValue
{
    /// <summary>
    /// Delegate that allows notification of any changes in the global value to ViewModel.
    /// </summary>
    public Action? Update;

    /// <summary>
    /// Gets or sets the Z-position associated with this global value.
    /// </summary>
    [JsonPropertyName("z_pos")]
    public double? ZPosition { get; set; }

    /// <summary>
    /// Gets or sets the value corresponding to this position.
    /// </summary>
    [JsonPropertyName("value")]
    public int? Value { get; set; }

    /// <summary>
    /// Invokes the <see cref="Update"/> action to notify ViewModel that this object's data has changed.
    /// </summary>
    public void InvokeUpdate()
    {
        Update?.Invoke();
    }
}
