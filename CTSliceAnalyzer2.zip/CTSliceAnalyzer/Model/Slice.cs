﻿using CTSliceAnalyzer.Global;
using System.Text.Json.Serialization;

namespace CTSliceAnalyzer.Model;

/// <summary>
/// Represents a single CT slice, storing the file name, raw data, dimensions and statistics such as minimum, maximum, and average values.
/// </summary>
public class Slice
{
    /// <summary>
    /// Delegate that can be invoked to notify ViewModel of changes to this slice.
    /// </summary>
    public Action? Update;

    /// <summary>
    /// Gets or sets the local file name from which the slice was loaded.
    /// </summary>
    [JsonIgnore]
    public string? FileName { get; set; }

    /// <summary>
    /// Gets or sets the raw data string containing values of the slice.
    /// </summary>
    [JsonIgnore]
    public string? RawData { get; set; }

    /// <summary>
    /// Gets or sets the Z-position of the slice in a CT scan.
    /// </summary>
    [JsonPropertyName("z_pos")]
    public double ZPosition { get; set; }

    /// <summary>
    /// Gets or sets the dimensions of this slice (width and height).
    /// </summary>
    [JsonPropertyName("dim")]
    public Dimensions Dimensions { get; set; }

    /// <summary>
    /// Gets or sets the minimum value found in this slice, along with the corresponding coordinates.
    /// </summary>
    [JsonPropertyName("min")]
    public SliceValue? MinValue { get; set; }

    /// <summary>
    /// Gets or sets the maximum value found in this slice, along with the corresponding coordinates.
    /// </summary>
    [JsonPropertyName("max")]
    public SliceValue? MaxValue { get; set; }

    /// <summary>
    /// Gets or sets the average value for this slice.
    /// Serialized using <see cref="DoubleTwoDecimalConverter"/> to ensure values are limited to two decimals.
    /// </summary>
    [JsonPropertyName("avg")]
    [JsonConverter(typeof(DoubleTwoDecimalConverter))]
    public double? AvgValue { get; set; }

    /// <summary>
    /// Invokes the <see cref="Update"/> action to notify ViewModel that the slice's data has changed.
    /// </summary>
    public void InvokeUpdate()
    {
        Update?.Invoke();
    }
}
