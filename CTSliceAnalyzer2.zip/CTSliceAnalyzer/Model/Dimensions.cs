﻿using System.Text.Json.Serialization;

namespace CTSliceAnalyzer.Model;

/// <summary>
/// A read-only struct representing the dimensions (width and height) of a CT slice.
/// </summary>
/// <param name="width">The width of the slice.</param>
/// <param name="height">The height of the slice.</param>
[method: JsonConstructor]
public readonly struct Dimensions(int width, int height)
{
    /// <summary>
    /// Gets the width of the slice.
    /// </summary>
    [JsonPropertyName("width")]
    public int Width { get; } = width;

    /// <summary>
    /// Gets the height of the slice.
    /// </summary>
    [JsonPropertyName("height")]
    public int Height { get; } = height;
}