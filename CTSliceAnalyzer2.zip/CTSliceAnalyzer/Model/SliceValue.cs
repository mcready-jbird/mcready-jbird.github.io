﻿using System.Text.Json.Serialization;

namespace CTSliceAnalyzer.Model;

/// <summary>
/// A read-only struct describing an value within a CT slice, including its coordinates.
/// </summary>
/// <param name="value">The value of the slice.</param>
/// <param name="x">The X-coordinate within the slice.</param>
/// <param name="y">The Y-coordinate within the slice.</param>
[method: JsonConstructor]
public readonly struct SliceValue(int value, int x = 0, int y = 0)
{
    /// <summary>
    /// Gets the intensity value of the slice.
    /// </summary>
    [JsonPropertyName("value")]
    public int Value { get; } = value;

    /// <summary>
    /// Gets the X-coordinate within the slice.
    /// </summary>
    [JsonPropertyName("x")]
    public int X { get; } = x;

    /// <summary>
    /// Gets the Y-coordinate within the slice.
    /// </summary>
    [JsonPropertyName("y")]
    public int Y { get; } = y;
}
