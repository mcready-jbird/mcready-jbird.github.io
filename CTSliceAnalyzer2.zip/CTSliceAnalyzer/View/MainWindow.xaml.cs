﻿using CTSliceAnalyzer.ViewModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace CTSliceAnalyzer.View;

/// <summary>
/// The main application window that hosts the <see cref="MainViewModel"/>, providing a data grid to display and automatically sort CT slices once they are loaded.
/// </summary>
public partial class MainWindow : Window
{
    /// <summary>
    /// Initializes a new instance of the <see cref="MainWindow"/> class and sets up data binding with the provided <see cref="MainViewModel"/>.
    /// Also attaches an event handler that applies sorting whenever the data grid's <see cref="ItemsControl.ItemsSource"/> changes.
    /// </summary>
    /// <param name="mainViewModel">The application's main ViewModel, containing slice data and operations.</param>
    public MainWindow(MainViewModel mainViewModel)
    {
        InitializeComponent();
        DataContext = mainViewModel;

        DependencyPropertyDescriptor
            .FromProperty(ItemsControl.ItemsSourceProperty, typeof(DataGrid))
            .AddValueChanged(SlicesDataGrid, OnItemsSourceChanged);
    }

    /// <summary>
    /// Event handler called when the data grid's <see cref="ItemsControl.ItemsSource"/> property changes.
    /// Triggers the automatic sorting of columns.
    /// </summary>
    /// <param name="sender">The source of the event, typically <see cref="SlicesDataGrid"/>.</param>
    /// <param name="e">Additional event data.</param>
    private void OnItemsSourceChanged(object? sender, EventArgs e)
    {
        ApplySorting();
    }

    /// <summary>
    /// Applies default sorting to the first column of the data grid, if available.
    /// Clears any existing <see cref="SortDescription"/>s before adding a new one and sets the first column's sort direction to ascending.
    /// </summary>
    private void ApplySorting()
    {
        if (SlicesDataGrid.Columns.Count == 0)
        {
            return;
        }

        var view = CollectionViewSource.GetDefaultView(SlicesDataGrid.ItemsSource);
        if (view == null)
        {
            return;
        }

        view.SortDescriptions.Clear();

        var firstColumn = SlicesDataGrid.Columns.FirstOrDefault();
        if (firstColumn?.SortMemberPath != null)
        {
            view.SortDescriptions.Add(
                new SortDescription(firstColumn.SortMemberPath, ListSortDirection.Ascending)
            );
            firstColumn.SortDirection = ListSortDirection.Ascending;
        }

        view.Refresh();
    }
}
