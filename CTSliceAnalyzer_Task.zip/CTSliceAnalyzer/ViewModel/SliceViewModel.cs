﻿using CommunityToolkit.Mvvm.ComponentModel;
using CTSliceAnalyzer.Model;

namespace CTSliceAnalyzer.ViewModel;

/// <summary>
/// Represents a ViewModel for a single slice in a CT scan, exposing
/// its Z-position, dimensions, and statistical data (minimum, maximum, average).
/// </summary>
public partial class SliceViewModel : ObservableObject
{
    /// <summary>
    /// Gets or sets the Z-position of the slice in the CT scan.
    /// </summary>
    [ObservableProperty]
    private double _zPosition;

    /// <summary>
    /// Gets or sets a string representing the dimensions of the slice (e.g., width x height).
    /// </summary>
    [ObservableProperty]
    private string? _dimensions;

    /// <summary>
    /// Gets or sets the minimum value found in the slice, along with its coordinates.
    /// </summary>
    [ObservableProperty]
    private string? _minValue;

    /// <summary>
    /// Gets or sets the maximum value found in the slice, along with its coordinates.
    /// </summary>
    [ObservableProperty]
    private string? _maxValue;

    /// <summary>
    /// Gets or sets the average value for the entire slice.
    /// </summary>
    [ObservableProperty]
    private double? _avgValue;

    /// <summary>
    /// Initializes a new instance of the <see cref="SliceViewModel"/> class, binding its properties to those of the provided <see cref="Slice"/> model.
    /// Registers an update action to automatically refresh this ViewModel when the underlying slice data changes.
    /// </summary>
    /// <param name="slice">The <see cref="Slice"/> whose data is represented by this ViewModel.</param>
    public SliceViewModel(Slice slice)
    {
        ZPosition = slice.ZPosition;
        Dimensions = $"{slice.Dimensions.Width} x {slice.Dimensions.Height}";
        UpdateValues(slice);

        slice.Update = () =>
        {
            UpdateValues(slice);
        };
    }

    /// <summary>
    /// Updates this ViewModel's properties based on the current state of the provided <see cref="Slice"/>.
    /// </summary>
    /// <param name="slice">The <see cref="Slice"/> containing the latest data.</param>
    private void UpdateValues(Slice slice)
    {
        MinValue = GetValueString(slice.MinValue);
        MaxValue = GetValueString(slice.MaxValue);
        AvgValue = slice.AvgValue;
    }

    /// <summary>
    /// Creates a string in the format "{Value} ({Y} x {X})", where Y corresponds to the row and X corresponds to the column.
    /// </summary>
    /// <param name="sliceValue">
    /// An object of type <see cref="SliceValue"/> containing the value and its row/column coordinates.
    /// </param>
    /// <returns>
    /// A string with the slice value and its coordinates in the format "(Row x Column)" or an empty string if <paramref name="sliceValue"/> is <c>null</c>.
    /// </returns>
    /// <remarks>
    /// See the Evaluation Task specifications point 2.
    /// </remarks>
    private static string GetValueString(SliceValue? sliceValue) => sliceValue == null ? string.Empty : $"{sliceValue?.Value} ({sliceValue?.Y} x {sliceValue?.X})";
}
