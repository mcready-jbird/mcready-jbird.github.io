﻿using CommunityToolkit.Mvvm.ComponentModel;
using CTSliceAnalyzer.Model;

namespace CTSliceAnalyzer.ViewModel;

/// <summary>
/// Represents a ViewModel for global values found in CT slices, including the Z-position and the integer value.
/// </summary>
public partial class GlobalValueViewModel : ObservableObject
{
    /// <summary>
    /// Gets or sets the Z position of the slice.
    /// </summary>
    [ObservableProperty]
    private double? _zPosition;

    /// <summary>
    /// Gets or sets the integer value associated with the slice.
    /// </summary>
    [ObservableProperty]
    private int? _value;

    /// <summary>
    /// Initializes a new instance of the <see cref="GlobalValueViewModel"/> class.
    /// Binds its properties to a <see cref="GlobalValue"/> model, and sets up a callback to automatically update this ViewModel when the model changes.
    /// </summary>
    /// <param name="globalValue">The <see cref="GlobalValue"/> instance whose data is represented by this ViewModel.</param>
    public GlobalValueViewModel(GlobalValue globalValue)
    {
        _zPosition = globalValue.ZPosition;
        _value = globalValue.Value;

        globalValue.Update = () =>
        {
            ZPosition = globalValue.ZPosition;
            Value = globalValue.Value;
        };
    }
}
