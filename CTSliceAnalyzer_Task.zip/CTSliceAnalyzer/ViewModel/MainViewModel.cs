﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CTSliceAnalyzer.Global;
using CTSliceAnalyzer.Model;
using CTSliceAnalyzer.Services;
using Microsoft.Win32;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Threading;

namespace CTSliceAnalyzer.ViewModel;

/// <summary>
/// MainViewModel is the primary ViewModel of the application.
/// It manages loading, processing, and saving CT slices, while providing progress updates and handling user interaction.
/// </summary>
public partial class MainViewModel : ObservableObject
{
    #region Dialog Constants

    /// <summary>
    /// The title used in the OpenFileDialog or SaveFileDialog for selecting a report.
    /// </summary>
    private const string ReportDialogTitle = "Select report";

    /// <summary>
    /// The filter used in the OpenFileDialog or SaveFileDialog when selecting a .report file.
    /// </summary>
    private const string ReportDialogFilter = "CT Slice Report (*.report)|*.report";

    #endregion

    #region Fields

    /// <summary>
    /// CancellationTokenSource used to cancel current operations (e.g., loading, processing slices, loading and saving report).
    /// </summary>
    [AllowNull]
    private CancellationTokenSource? _cancellationTokenSource;

    /// <summary>
    /// Measures elapsed time for load/process operations.
    /// </summary>
    private readonly Stopwatch _stopWatch = new();

    /// <summary>
    /// Service responsible for loading and processing slices.
    /// </summary>
    private readonly ISliceService _sliceService;

    /// <summary>
    /// Service responsible for saving and loading the report.
    /// </summary>
    private readonly IReportService _reportService;

    /// <summary>
    /// Indicates whether slices have been loaded successfully.
    /// </summary>
    private bool _areSlicesLoaded;

    /// <summary>
    /// Indicates whether slices have been processed successfully.
    /// </summary>
    private bool _areSlicesProcessed;

    /// <summary>
    /// Indicates whether the report was loaded from a file.
    /// </summary>
    private bool _isReportLoaded;

    /// <summary>
    /// Accumulates the sum of average values from processed slices.
    /// </summary>
    private double _globalTotalValue;

    #endregion

    #region Slice Processing UI

    /// <summary>
    /// Timer used to periodically update the UI with processed slice data.
    /// </summary>
    private readonly DispatcherTimer _processTimer = new() { Interval = TimeSpan.FromMicroseconds(1) };

    /// <summary>
    /// Thread-safe queue that collects processed slices before updating the UI.
    /// </summary>
    private readonly ConcurrentQueue<Slice> _processQueue = new();

    #endregion

    #region Observable Properties

    /// <summary>
    /// The ViewModel representing the report, including global stats and slice details.
    /// </summary>
    [ObservableProperty]
    private ReportViewModel _report = new(new Report());

    /// <summary>
    /// Current progress counter (e.g., how many slices have been loaded or processed).
    /// </summary>
    [ObservableProperty]
    private int _currentProgress;

    /// <summary>
    /// Maximum value for progress operations (e.g., total slices to load/process).
    /// </summary>
    [ObservableProperty]
    private int _maxProgress;

    /// <summary>
    /// Indicates whether the Cancel button is enabled.
    /// </summary>
    [ObservableProperty]
    private bool _isCancelEnabled;

    /// <summary>
    /// Indicates whether the main menu is enabled.
    /// </summary>
    [ObservableProperty]
    private bool _isMenuEnabled = true;

    /// <summary>
    /// Shows or hides text showing current progress.
    /// </summary>
    [ObservableProperty]
    private bool _isProgressTextVisible;

    /// <summary>
    /// Shows or hides the progress bar.
    /// </summary>
    [ObservableProperty]
    private bool _isProgressBarVisible;

    /// <summary>
    /// Text that displays progress information, e.g., "2/10 (3.123 seconds)".
    /// </summary>
    [ObservableProperty]
    private string? _progressText;

    #endregion

    #region Constructor

    /// <summary>
    /// Initializes a new instance of the <see cref="MainViewModel"/> class with the specified services.
    /// </summary>
    /// <param name="sliceService">Service for loading and processing slices.</param>
    /// <param name="reportService">Service for saving and loading reports.</param>
    public MainViewModel(ISliceService sliceService, IReportService reportService)
    {
        _processTimer.Tick += (sender, e) =>
        {
            UpdateProcessedSlices();
        };

        _sliceService = sliceService;
        _sliceService.Loaded += SliceService_SliceLoaded;
        _sliceService.Processed += SliceService_SliceProcessed;

        _reportService = reportService;
    }

    #endregion

    #region Progress

    /// <summary>
    /// Starts progress tracking, resetting counters and optionally enabling real-time slice processing updates.
    /// </summary>
    /// <param name="maxProgress">If not null, sets the maximum progress value for the progress bar.</param>
    /// <param name="updateProcessedSlices">If true, starts a DispatcherTimer to refresh processed slices in the main thread.</param>
    private void StartProgress(int? maxProgress = null, bool updateProcessedSlices = false)
    {
        _cancellationTokenSource = new CancellationTokenSource();
        if (maxProgress != null)
        {
            MaxProgress = maxProgress.Value;
            CurrentProgress = 0;
            IsProgressBarVisible = true;
        }
        else
        {
            IsProgressBarVisible = false;
        }
        IsProgressTextVisible = true;
        IsMenuEnabled = false;
        IsCancelEnabled = true;
        _stopWatch.Restart();
        if (updateProcessedSlices)
        {
            _processTimer.Start();
        }
    }

    /// <summary>
    /// Stops progress tracking. If no error occurred and the operation was not canceled, hides the progress bar.
    /// </summary>
    /// <param name="isError">If true, keeps the progress bar visible to indicate an error state.</param>
    private void StopProgress(bool isError)
    {
        _stopWatch.Stop();
        IsMenuEnabled = true;
        IsCancelEnabled = false;
        if (!isError && _cancellationTokenSource?.IsCancellationRequested == false)
        {
            IsProgressBarVisible = false;
        }
        if (_processTimer.IsEnabled)
        {
            _processTimer.Stop();
            UpdateProcessedSlices();
        }
        _cancellationTokenSource = null;
    }

    /// <summary>
    /// Command that cancels ongoing operations by triggering the CancellationToken.
    /// </summary>
    [RelayCommand]
    private void Cancel()
    {
        _cancellationTokenSource?.Cancel();
    }

    /// <summary>
    /// Called automatically when the CurrentProgress property changes.
    /// Updates the ProgressText to show current progress and elapsed time.
    /// </summary>
    /// <param name="value">The new CurrentProgress value.</param>
    partial void OnCurrentProgressChanged(int value)
    {
        ProgressText = $"{CurrentProgress}/{MaxProgress} ({_stopWatch.Elapsed:ss\\.fff} seconds)";
    }

    /// <summary>
    /// Shows an info message box.
    /// </summary>
    /// <param name="text">The info text to display.</param>
    private static void ShowInfo(string text)
    {
        MessageBox.Show(text, "Info", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    /// <summary>
    /// Shows a warning message box with Yes/No buttons.
    /// </summary>
    /// <param name="text">The warning text to display.</param>
    /// <returns>True if the user clicks Yes, false otherwise.</returns>
    private static bool ShowWarning(string text)
    {
        return MessageBox.Show(text, "Warning", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;
    }

    /// <summary>
    /// Shows an error message box by wrapping the provided string in an exception.
    /// </summary>
    /// <param name="message">The error message to display.</param>
    private static void ShowError(string message)
    {
        ShowError(new Exception(message));
    }

    /// <summary>
    /// Shows an error message box for the provided exception.
    /// Uses <see cref="ExceptionExtensions.ToShortString"/> to format the exception message.
    /// </summary>
    /// <param name="ex">The exception to display.</param>
    private static void ShowError(Exception ex)
    {
        MessageBox.Show(ex.ToShortString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
    }

    #endregion

    #region Loading Slices

    /// <summary>
    /// Loads CT slices asynchronously from a user-selected folder.
    /// Displays a folder selection dialog and searches for files matching "slice*.txt".
    /// </summary>
    [RelayCommand]
    private async Task LoadSlices()
    {
        try
        {
            OpenFolderDialog folderDialog = new()
            {
                Title = "Select directory"
            };
            if (folderDialog.ShowDialog() == true)
            {
                var fileNames = Directory.GetFiles(folderDialog.FolderName, "slice*.txt").OrderBy(fileName =>
                {
                    var match = Regex.Match(fileName, @"\d+");
                    return match.Success ? int.Parse(match.Value) : 0;
                });
                if (fileNames == null || !fileNames.Any())
                {
                    ShowError("No CT slices found!");
                    return;
                }
                StartProgress(fileNames.Count());
                _areSlicesLoaded = false;
                _areSlicesProcessed = false;
                _isReportLoaded = false;
                Report = new(new Report());
                await _sliceService.LoadSlices(fileNames, _cancellationTokenSource.Token);
                _areSlicesLoaded = true;
                StopProgress(false);
            }
        }
        catch (OperationCanceledException)
        {
            StopProgress(true);
        }
        catch (Exception ex)
        {
            StopProgress(true);
            ShowError(ex);
        }
    }

    /// <summary>
    /// Handles the <see cref="ISliceService.Loaded"/> event when a slice is loaded.
    /// Adds the loaded slice to the Report and increments CurrentProgress.
    /// </summary>
    /// <param name="slice">The loaded slice object.</param>
    private void SliceService_SliceLoaded(Slice slice)
    {
        Report.AddSlice(slice);
        CurrentProgress++;
    }

    #endregion

    #region Processing Slices

    /// <summary>
    /// Initiates parallel processing of previously loaded slices.
    /// Updates slice statistics (min, max, average values, etc.).
    /// </summary>
    [RelayCommand]
    private async Task ProcessSlices()
    {
        if (_isReportLoaded)
        {
            ShowError("The slices have been loaded from the report.\n\nPlease load the slices if you want to process them.");
            return;
        }
        if (!Report.Slices.Any())
        {
            ShowError("No slices are loaded.\n\nPlease load the slices if you want to process them.");
            return;
        }
        if (!_areSlicesLoaded && !ShowWarning("Slices have not been completely loaded.\n\nDo you want to process?"))
        {
            return;
        }
        try
        {
            StartProgress(Report.Slices.Count, true);
            _areSlicesProcessed = false;
            _globalTotalValue = 0.0;
            await _sliceService.ProcessSlices(Report.Model, _cancellationTokenSource.Token);
            _areSlicesProcessed = true;
            StopProgress(false);
        }
        catch (OperationCanceledException)
        {
            StopProgress(true);
        }
        catch (Exception ex)
        {
            StopProgress(true);
            ShowError(ex);
        }
    }

    /// <summary>
    /// Handles the <see cref="ISliceService.Processed"/> event when a slice is processed in a separate thread.
    /// Queues the processed slice for later UI updates.
    /// </summary>
    /// <param name="slice">The processed slice object.</param>
    private void SliceService_SliceProcessed(Slice slice)
    {
        _processQueue.Enqueue(slice);
    }

    /// <summary>
    /// Periodically called by the DispatcherTimer to update current progress, processed slices and global values (min, max, average) on the main thread.
    /// Dequeues slices from <see cref="_processQueue"/> and updates global stats.
    /// </summary>
    private void UpdateProcessedSlices()
    {
        var report = Report.Model;

        bool updateGlobalMinValue = false;
        bool updateGlobalMaxValue = false;

        int progressCount = 0;
        while (_processQueue.TryDequeue(out Slice? slice))
        {
            slice.InvokeUpdate();

            if ((slice.MinValue?.Value ?? int.MaxValue) < (report.GlobalMinValue.Value ?? int.MaxValue))
            {
                report.GlobalMinValue.ZPosition = slice.ZPosition;
                report.GlobalMinValue.Value = slice.MinValue?.Value ?? 0;
                updateGlobalMinValue = true;
            }
            if ((slice.MaxValue?.Value ?? int.MinValue) > (report.GlobalMaxValue.Value ?? int.MinValue))
            {
                report.GlobalMaxValue.ZPosition = slice.ZPosition;
                report.GlobalMaxValue.Value = slice.MaxValue?.Value ?? 0;
                updateGlobalMaxValue = true;
            }
            _globalTotalValue += slice.AvgValue ?? 0.0;

            progressCount++;
        }

        if (progressCount > 0)
        {
            CurrentProgress += progressCount;

            if (updateGlobalMinValue)
            {
                report.GlobalMinValue.InvokeUpdate();
            }
            if (updateGlobalMaxValue)
            {
                report.GlobalMaxValue.InvokeUpdate();
            }
            double avgValue = Math.Round(_globalTotalValue / CurrentProgress, 2);
            if (report.GlobalAvgValue != avgValue)
            {
                report.GlobalAvgValue = avgValue;
                report.InvokeUpdate();
            }
        }
    }

    #endregion

    #region Report Management

    /// <summary>
    /// Loads a previously saved CT slice report from a file chosen by the user.
    /// </summary>
    [RelayCommand]
    private async Task LoadReport()
    {
        try
        {
            var openFileDialog = new OpenFileDialog
            {
                Title = ReportDialogTitle,
                Filter = ReportDialogFilter
            };
            if (openFileDialog.ShowDialog() == true)
            {
                StartProgress();
                ProgressText = "Loading...";
                Report = new ReportViewModel(await _reportService.LoadReport(openFileDialog.FileName, _cancellationTokenSource.Token));
                _isReportLoaded = true;
                StopProgress(false);

                string fileName = $"\"{Path.GetFileName(openFileDialog.FileName)}\"";
                ProgressText = $"Loaded {fileName} ({Report.Slices.Count}/{Report.Slices.Count})";
                ShowInfo($"Report is loaded from {fileName}");
            }
        }
        catch (OperationCanceledException)
        {
            StopProgress(true);
        }
        catch (Exception ex)
        {
            StopProgress(true);
            ShowError(ex);
        }
    }

    /// <summary>
    /// Saves the current CT slice report to a file chosen by the user.
    /// </summary>
    [RelayCommand]
    private async Task SaveReport()
    {
        if (Report.Slices.Count == 0)
        {
            ShowError("Slices have not been loaded.\n\nPlease load and process them before saving the report.");
            return;
        }
        if (!_isReportLoaded && !_areSlicesLoaded && !ShowWarning("Slices have not been completely loaded.\n\nDo you want to save the report?"))
        {
            return;
        }
        if (!_isReportLoaded && !_areSlicesProcessed && !ShowWarning("Slices have not been completely processed.\n\nDo you want to save the report?"))
        {
            return;
        }
        try
        {
            var saveFileDialog = new SaveFileDialog
            {
                Title = ReportDialogTitle,
                Filter = ReportDialogFilter
            };
            if (saveFileDialog.ShowDialog() == true)
            {
                StartProgress();
                ProgressText = "Saving...";
                await _reportService.SaveReport(saveFileDialog.FileName, Report.Model, _cancellationTokenSource.Token);
                StopProgress(false);

                string fileName = $"\"{Path.GetFileName(saveFileDialog.FileName)}\"";
                ProgressText = $"Saved {fileName}";
                ShowInfo($"Report is saved to {fileName}");
            }
        }
        catch (OperationCanceledException)
        {
            StopProgress(true);
        }
        catch (Exception ex)
        {
            StopProgress(true);
            ShowError(ex);
        }
    }

    #endregion
}
