﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CTSliceAnalyzer.Utils;
using CTSliceAnalyzer.Model;
using CTSliceAnalyzer.Services;
using Microsoft.Win32;
using System.Collections.Concurrent;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Threading;

namespace CTSliceAnalyzer.ViewModel;

/// <summary>
/// The primary ViewModel of the application. Handles loading, processing, and saving CT slices, manages progress, and handles user interactions.
/// </summary>
public partial class MainViewModel : ObservableObject
{
    /// <summary>
    /// The title used in file dialogs for selecting a report file.
    /// </summary>
    private const string ReportDialogTitle = "Select report";

    /// <summary>
    /// The filter used in file dialogs for *.report files.
    /// </summary>
    private const string ReportDialogFilter = "CT Slice Report (*.report)|*.report";

    /// <summary>
    /// Timer that periodically updates UI with processed slice data.
    /// </summary>
    private readonly DispatcherTimer _processTimer = new() { Interval = TimeSpan.FromMicroseconds(1) };

    /// <summary>
    /// Thread-safe queue holding processed slices before UI updates.
    /// </summary>
    private readonly ConcurrentQueue<Slice> _processQueue = new();

    /// <summary>
    /// Service responsible for loading and processing CT slices.
    /// </summary>
    private readonly ISliceService _sliceService;

    /// <summary>
    /// Service responsible for saving and loading reports.
    /// </summary>
    private readonly IReportService _reportService;

    /// <summary>
    /// Indicates if slices have been fully loaded.
    /// </summary>
    private bool _areSlicesLoaded;

    /// <summary>
    /// Indicates if slices have been completely processed.
    /// </summary>
    private bool _areSlicesProcessed;

    /// <summary>
    /// Indicates if the report was loaded from a file.
    /// </summary>
    private bool _isReportLoaded;

    /// <summary>
    /// Sum of average values from processed slices.
    /// </summary>
    private double _globalTotalValue;

    /// <summary>
    /// The ViewModel holding the report data and slice details.
    /// </summary>
    [ObservableProperty]
    private ReportViewModel _report = new(new Report());

    /// <summary>
    /// Tracks progress and handles cancellation of long-running tasks.
    /// </summary>
    [ObservableProperty]
    private ProgressViewModel _progress = new();

    /// <summary>
    /// Initializes a new MainViewModel with specified services.
    /// </summary>
    public MainViewModel(ISliceService sliceService, IReportService reportService)
    {
        _processTimer.Tick += (sender, e) => UpdateProcessedSlices();

        _sliceService = sliceService;
        _sliceService.Loaded += SliceService_SliceLoaded;
        _sliceService.Processed += SliceService_SliceProcessed;

        _reportService = reportService;
    }

    #region Loading Slices

    /// <summary>
    /// Asynchronously loads CT slices from a user-selected folder. Looks for files matching "slice*.txt" and updates progress.
    /// </summary>
    [RelayCommand]
    private async Task LoadSlices()
    {
        try
        {
            OpenFolderDialog folderDialog = new()
            {
                Title = "Select directory"
            };

            if (folderDialog.ShowDialog() == true)
            {
                var fileNames = Directory
                    .GetFiles(folderDialog.FolderName, "slice*.txt")
                    .OrderBy(fileName =>
                    {
                        var match = Regex.Match(fileName, @"\d+");
                        return match.Success ? int.Parse(match.Value) : 0;
                    });

                if (fileNames == null || !fileNames.Any())
                {
                    ShowMessage.Error("No CT slices found!");
                    return;
                }

                Progress.Start(fileNames.Count());
                _areSlicesLoaded = false;
                _areSlicesProcessed = false;
                _isReportLoaded = false;
                Report = new(new Report());

                await _sliceService.LoadSlices(fileNames, Progress.CancellationToken);
                _areSlicesLoaded = true;

                Progress.Stop();
            }
        }
        catch (Exception ex)
        {
            Progress.Stop(ex);
        }
    }

    /// <summary>
    /// Handles SliceLoaded event. Adds slice to the Report and increments progress.
    /// </summary>
    private void SliceService_SliceLoaded(Slice slice)
    {
        Report.AddSlice(slice);
        Progress.CurrentValue++;
    }

    #endregion

    #region Processing Slices

    /// <summary>
    /// Initiates parallel processing of loaded slices and updates slice statistics.
    /// </summary>
    [RelayCommand]
    private async Task ProcessSlices()
    {
        if (_isReportLoaded)
        {
            ShowMessage.Error("Slices are loaded from the report. Please load them first if you want to process.");
            return;
        }

        if (!Report.Slices.Any())
        {
            ShowMessage.Error("No slices loaded. Please load slices before processing.");
            return;
        }

        if (!_areSlicesLoaded && !ShowMessage.Warning("Slices have not been completely loaded. Process anyway?"))
        {
            return;
        }
        try
        {
            Progress.Start(Report.Slices.Count);
            _processTimer.Start();
            _areSlicesProcessed = false;
            _globalTotalValue = 0.0;

            await _sliceService.ProcessSlices(Report.Model, Progress.CancellationToken);
            _areSlicesProcessed = true;

            Progress.Stop();
        }
        catch (Exception ex)
        {
            Progress.Stop(ex);
        }
        finally
        {
            _processTimer.Stop();
            UpdateProcessedSlices();
        }
    }

    /// <summary>
    /// Handles Processed event. Adds processed slice to the queue for UI updates.
    /// </summary>
    private void SliceService_SliceProcessed(Slice slice)
    {
        _processQueue.Enqueue(slice);
    }

    /// <summary>
    /// Updates processed slices on each timer tick in the main thread. Dequeues slices and updates global min, max, and average values.
    /// </summary>
    private void UpdateProcessedSlices()
    {
        var report = Report.Model;

        bool updateGlobalMinValue = false;
        bool updateGlobalMaxValue = false;

        int progressCount = 0;
        while (_processQueue.TryDequeue(out Slice? slice))
        {
            slice.InvokeUpdate();

            if ((slice.MinValue?.Value ?? int.MaxValue) < (report.GlobalMinValue.Value ?? int.MaxValue))
            {
                report.GlobalMinValue.ZPosition = slice.ZPosition;
                report.GlobalMinValue.Value = slice.MinValue?.Value;
                updateGlobalMinValue = true;
            }

            if ((slice.MaxValue?.Value ?? int.MinValue) > (report.GlobalMaxValue.Value ?? int.MinValue))
            {
                report.GlobalMaxValue.ZPosition = slice.ZPosition;
                report.GlobalMaxValue.Value = slice.MaxValue?.Value;
                updateGlobalMaxValue = true;
            }

            _globalTotalValue += slice.AvgValue ?? 0.0;
            progressCount++;
        }

        if (progressCount > 0)
        {
            Progress.CurrentValue += progressCount;

            if (updateGlobalMinValue)
            {
                report.GlobalMinValue.InvokeUpdate();
            }
            if (updateGlobalMaxValue)
            {
                report.GlobalMaxValue.InvokeUpdate();
            }

            double avgValue = Math.Round(_globalTotalValue / Progress.CurrentValue, 2);
            if (report.GlobalAvgValue != avgValue)
            {
                report.GlobalAvgValue = avgValue;
                report.InvokeUpdate();
            }
        }
    }

    #endregion

    #region Report Management

    /// <summary>
    /// Loads a previously saved report file (.report).
    /// </summary>
    [RelayCommand]
    private async Task LoadReport()
    {
        try
        {
            var openFileDialog = new OpenFileDialog
            {
                Title = ReportDialogTitle,
                Filter = ReportDialogFilter
            };

            if (openFileDialog.ShowDialog() == true)
            {
                Progress.Start();
                Progress.Text = "Loading...";

                Report = new ReportViewModel(await _reportService.LoadReport(openFileDialog.FileName, Progress.CancellationToken));
                _isReportLoaded = true;

                Progress.Stop();

                string fileName = $"\"{Path.GetFileName(openFileDialog.FileName)}\"";
                Progress.Text = $"Loaded {fileName} ({Report.Slices.Count}/{Report.Slices.Count})";
                ShowMessage.Info($"Report is loaded from {fileName}");
            }
        }
        catch (Exception ex)
        {
            Progress.Stop(ex);
            Progress.Text = "Error loading report";
        }
    }

    /// <summary>
    /// Saves the current report to a .report file.
    /// </summary>
    [RelayCommand]
    private async Task SaveReport()
    {
        if (Report.Slices.Count == 0)
        {
            ShowMessage.Error("No slices to save. Load and process them first.");
            return;
        }

        if (!_isReportLoaded && !_areSlicesLoaded &&
            !ShowMessage.Warning("Slices have not been completely loaded. Proceed anyway?"))
        {
            return;
        }

        if (!_isReportLoaded && !_areSlicesProcessed &&
            !ShowMessage.Warning("Slices have not been completely processed. Proceed anyway?"))
        {
            return;
        }
        try
        {
            var saveFileDialog = new SaveFileDialog
            {
                Title = ReportDialogTitle,
                Filter = ReportDialogFilter
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                Progress.Start();
                Progress.Text = "Saving...";

                await _reportService.SaveReport(saveFileDialog.FileName, Report.Model, Progress.CancellationToken);
                Progress.Stop();

                string fileName = $"\"{Path.GetFileName(saveFileDialog.FileName)}\"";
                Progress.Text = $"Saved {fileName}";
                ShowMessage.Info($"Report is saved to {fileName}");
            }
        }
        catch (Exception ex)
        {
            Progress.Stop(ex);
            Progress.Text = "Error saving report";
        }
    }

    #endregion
}
