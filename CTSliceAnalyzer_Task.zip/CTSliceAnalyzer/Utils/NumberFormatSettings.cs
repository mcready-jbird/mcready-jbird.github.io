﻿using System.Globalization;

namespace CTSliceAnalyzer.Utils;

/// <summary>
/// Contains a shared <see cref="NumberFormatInfo"/> instance with a period ('.') as the decimal separator, facilitating consistent numeric parsing.
/// </summary>
public static class NumberFormatSettings
{
    /// <summary>
    /// A <see cref="NumberFormatInfo"/> configured to use '.' as the decimal separator.
    /// This is used throughout the application for parsing and formatting numeric values.
    /// </summary>
    public static readonly NumberFormatInfo NumberFormatInfo = new()
    {
        NumberDecimalSeparator = "."
    };
}