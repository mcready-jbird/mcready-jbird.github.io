﻿using System.Windows;

namespace CTSliceAnalyzer.Utils;

/// <summary>
/// Provides static methods for displaying WPF message boxes of various types:
/// informational, warning (with Yes/No prompt), and error messages.
/// </summary>
public static class ShowMessage
{
    /// <summary>
    /// Shows an info message box.
    /// </summary>
    /// <param name="text">The info text to display.</param>
    public static void Info(string text)
    {
        MessageBox.Show(text, "Info", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    /// <summary>
    /// Shows a warning message box with Yes/No buttons.
    /// </summary>
    /// <param name="text">The warning text to display.</param>
    /// <returns>True if the user clicks Yes, false otherwise.</returns>
    public static bool Warning(string text)
    {
        return MessageBox.Show(text, "Warning", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;
    }

    /// <summary>
    /// Shows an error message box by wrapping the provided string in an exception.
    /// </summary>
    /// <param name="message">The error message to display.</param>
    public static void Error(string message)
    {
        Error(new Exception(message));
    }

    /// <summary>
    /// Shows an error message box for the provided exception.
    /// Uses <see cref="ExceptionExtensions.ToShortString"/> to format the exception message.
    /// </summary>
    /// <param name="ex">The exception to display.</param>
    public static void Error(Exception ex)
    {
        MessageBox.Show(ex.ToShortString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
    }
}
