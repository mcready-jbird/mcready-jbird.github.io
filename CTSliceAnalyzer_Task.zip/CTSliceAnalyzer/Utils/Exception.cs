﻿using System.Text;

namespace CTSliceAnalyzer.Utils;

/// <summary>
/// Provides extension methods for exceptions, such as generating simplified error messages.
/// </summary>
public static class ExceptionExtensions
{
    /// <summary>
    /// Creates a string that includes the main exception message as well as any inner exception messages, indenting each inner message for clarity.
    /// </summary>
    /// <param name="ex">The exception whose messages are converted into a short string.</param>
    /// <returns>A concatenated string of all exception messages, separated by new lines.</returns>
    public static string ToShortString(this Exception? ex)
    {
        var sb = new StringBuilder();
        int lineCount = 0;

        while (ex != null)
        {
            if (lineCount > 0)
            {
                sb.Append($"{new string('-', lineCount)}>");
            }

            sb.AppendLine(ex.Message);
            ex = ex.InnerException;
            lineCount++;
        }

        return sb.ToString();
    }
}
