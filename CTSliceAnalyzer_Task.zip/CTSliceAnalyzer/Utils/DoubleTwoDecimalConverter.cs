﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace CTSliceAnalyzer.Utils;

/// <summary>
/// A custom JSON converter that rounds nullable double values to two decimal places before serialization, and reads them back as <c>double?</c> values.
/// </summary>
public class DoubleTwoDecimalConverter : JsonConverter<double?>
{
    /// <summary>
    /// Reads a nullable double value from the JSON input.
    /// If the token is null, returns <c>null</c>; otherwise, returns the parsed double value without additional rounding.
    /// </summary>
    /// <param name="reader">The <see cref="Utf8JsonReader"/> to read data from.</param>
    /// <param name="typeToConvert">The expected type to convert (ignored).</param>
    /// <param name="options">Serialization options (ignored in this converter).</param>
    /// <returns>A nullable double value.</returns>
    public override double? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType == JsonTokenType.Null)
            return null;

        return reader.GetDouble();
    }

    /// <summary>
    /// Writes a nullable double value to the JSON output, rounding to two decimals.
    /// If the value is <c>null</c>, writes <c>null</c>.
    /// </summary>
    /// <param name="writer">The <see cref="Utf8JsonWriter"/> to write data to.</param>
    /// <param name="value">The nullable double value to convert.</param>
    /// <param name="options">Serialization options (ignored in this converter).</param>
    public override void Write(Utf8JsonWriter writer, double? value, JsonSerializerOptions options)
    {
        if (value.HasValue)
        {
            writer.WriteNumberValue(Math.Round(value.Value, 2));
        }
        else
        {
            writer.WriteNullValue();
        }
    }
}
