﻿using CTSliceAnalyzer.ViewModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace CTSliceAnalyzer.View;

public partial class MainWindow : Window
{
    public MainWindow(MainViewModel mainViewModel)
    {
        InitializeComponent();
        DataContext = mainViewModel;

        DependencyPropertyDescriptor
            .FromProperty(ItemsControl.ItemsSourceProperty, typeof(DataGrid))
            .AddValueChanged(SlicesDataGrid, OnItemsSourceChanged);
    }

    private void OnItemsSourceChanged(object? sender, EventArgs e)
    {
        ApplySorting();
    }

    private void ApplySorting()
    {
        if (SlicesDataGrid.Columns.Count == 0)
        {
            return;
        }
        var view = CollectionViewSource.GetDefaultView(SlicesDataGrid.ItemsSource);
        if (view == null)
        {
            return;
        }
        view.SortDescriptions.Clear();

        var firstColumn = SlicesDataGrid.Columns.FirstOrDefault();
        if (firstColumn?.SortMemberPath != null)
        {
            view.SortDescriptions.Add(new SortDescription(firstColumn.SortMemberPath, ListSortDirection.Ascending));
            firstColumn.SortDirection = ListSortDirection.Ascending;
        }
        view.Refresh();
    }
}