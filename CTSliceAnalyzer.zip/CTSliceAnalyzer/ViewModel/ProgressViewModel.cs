﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CTSliceAnalyzer.Global;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;

namespace CTSliceAnalyzer.ViewModel
{
    /// <summary>
    /// Manages progress tracking for long-running operations, providing cancellation, elapsed time measurement, and real-time status updates in the UI.
    /// </summary>
    public partial class ProgressViewModel : ObservableObject
    {
        /// <summary>
        /// Token source for canceling current operations.
        /// </summary>
        private CancellationTokenSource? _cancellationTokenSource;

        /// <summary>
        /// Stopwatch measuring elapsed time.
        /// </summary>
        private readonly Stopwatch _stopWatch = new();

        /// <summary>
        /// Current progress counter (e.g., slices processed).
        /// </summary>
        [ObservableProperty]
        private int _currentValue;

        /// <summary>
        /// Maximum progress value (e.g., total slices).
        /// </summary>
        [ObservableProperty]
        private int _maxValue;

        /// <summary>
        /// Indicates if the Cancel button is enabled.
        /// </summary>
        [ObservableProperty]
        private bool _isCancelEnabled;

        /// <summary>
        /// Indicates if the main menu is enabled.
        /// </summary>
        [ObservableProperty]
        private bool _isMenuEnabled = true;

        /// <summary>
        /// Shows or hides progress text.
        /// </summary>
        [ObservableProperty]
        private bool _isTextVisible;

        /// <summary>
        /// Shows or hides the progress bar.
        /// </summary>
        [ObservableProperty]
        private bool _isProgressBarVisible;

        /// <summary>
        /// Text displaying current progress, e.g. "2/10 (3.123 seconds)".
        /// </summary>
        [ObservableProperty]
        private string? _Text;

        /// <summary>
        /// Exposes the current CancellationToken.
        /// </summary>
        public CancellationToken CancellationToken => _cancellationTokenSource.Token;

        /// <summary>
        /// Starts progress tracking. Resets counters, shows the progress bar and sets the maximum progress value.
        /// </summary>
        public void Start(int? maxProgress = null)
        {
            _cancellationTokenSource = new CancellationTokenSource();

            if (maxProgress != null)
            {
                CurrentValue = 0;
                MaxValue = maxProgress.Value;
                IsProgressBarVisible = true;
            }
            else
            {
                IsProgressBarVisible = false;
            }

            IsTextVisible = true;
            IsMenuEnabled = false;
            IsCancelEnabled = true;
            _stopWatch.Restart();
        }

        /// <summary>
        /// Stops progress. Hides the progress bar unless an error occurred or the operation was canceled.
        /// </summary>
        public void Stop(Exception? ex = null)
        {
            _stopWatch.Stop();
            IsMenuEnabled = true;
            IsCancelEnabled = false;
            _cancellationTokenSource = null;

            if (ex == null)
            {
                IsProgressBarVisible = false;
            }
            else if (ex is not OperationCanceledException)
            {
                ShowMessage.Error(ex);
            }
        }

        /// <summary>
        /// Cancels current operations via the token source.
        /// </summary>
        [RelayCommand]
        public void Cancel()
        {
            _cancellationTokenSource?.Cancel();
        }

        /// <summary>
        /// Updates the progress text whenever CurrentValue changes.
        /// </summary>
        partial void OnCurrentValueChanged(int value)
        {
            Text = $"{CurrentValue}/{MaxValue} ({_stopWatch.Elapsed:ss\\.fff} seconds)";
        }
    }
}
