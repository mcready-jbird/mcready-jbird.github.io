﻿using CommunityToolkit.Mvvm.ComponentModel;
using CTSliceAnalyzer.Model;

namespace CTSliceAnalyzer.ViewModel
{
    public partial class GlobalValueViewModel : ObservableObject
    {
        [ObservableProperty]
        private double? _zPosition;

        [ObservableProperty]
        private int? _value;

        public GlobalValueViewModel(GlobalValue globalValue)
        {
            _zPosition = globalValue.ZPosition;
            _value = globalValue.Value;

            globalValue.Update = () =>
            {
                ZPosition = globalValue.ZPosition;
                Value = globalValue.Value;
            };
        }
    }
}
