﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CTSliceAnalyzer.Global;
using CTSliceAnalyzer.Model;
using CTSliceAnalyzer.Services;
using Microsoft.Win32;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Threading;

namespace CTSliceAnalyzer.ViewModel;

public partial class MainViewModel : ObservableObject
{
    private const string ReportDialogTitle = "Select report";

    private const string ReportDialogFilter = "CT Slice Report (*.report)|*.report";

    private readonly Stopwatch _stopWatch = new();

    private ISliceService _sliceService;

    private IReportService _reportService;

    private bool _areSlicesLoaded;

    private bool _areSlicesProcessed;

    private bool _isReportLoaded;

    private double _globalTotalValue;

    [AllowNull]
    private CancellationTokenSource? _cancellationTokenSource;

    [ObservableProperty]
    private ReportViewModel _report = new(new Report());

    [ObservableProperty]
    private int _currentProgress;

    [ObservableProperty]
    private int _maxProgress;

    [ObservableProperty]
    private bool _isCancelEnabled;

    [ObservableProperty]
    private bool _isMenuEnabled = true;

    [ObservableProperty]
    private bool _isProgressTextVisible;

    [ObservableProperty]
    private bool _isProgressBarVisible;

    [ObservableProperty]
    private string? _progressText;

    public MainViewModel(ISliceService sliceService, IReportService reportService)
    {
        _sliceService = sliceService;
        _sliceService.Loaded += SliceService_SliceLoaded;
        _sliceService.Processed += SliceService_SliceProcessed;

        _reportService = reportService;
    }

    [RelayCommand]
    private async Task LoadSlices()
    {
        try
        {
            OpenFolderDialog folderDialog = new OpenFolderDialog();
            folderDialog.Title = "Select directory";
            if (folderDialog.ShowDialog() == true)
            {
                var fileNames = Directory.GetFiles(folderDialog.FolderName, "slice*.txt").OrderBy(fileName =>
                {
                    var match = Regex.Match(fileName, @"\d+");
                    return match.Success ? int.Parse(match.Value) : 0;
                });
                if (fileNames == null || !fileNames.Any())
                {
                    ShowError("No CT slices found!");
                    return;
                }
                StartProgress(fileNames.Count());
                _areSlicesLoaded = false;
                _areSlicesProcessed = false;
                _isReportLoaded = false;
                Report = new(new Report());
                await _sliceService.LoadSlices(fileNames, _cancellationTokenSource.Token);
                _areSlicesLoaded = true;
                StopProgress(false);
            }
        }
        catch (OperationCanceledException)
        {
            StopProgress(true);
        }
        catch (Exception ex)
        {
            StopProgress(true);
            ShowError(ex);
        }
    }

    private void SliceService_SliceLoaded(Slice slice)
    {
        Report.AddSlice(slice);
        CurrentProgress++;
    }

    [RelayCommand]
    private async Task ProcessSlices()
    {
        if (_isReportLoaded)
        {
            ShowError("The slices have been loaded from the report.\n\nPlease load the slices if you want to process them.");
            return;
        }
        if (!_areSlicesLoaded && !ShowWarning("Slices have not been completely loaded.\n\nDo you want to process?"))
        {
            return;
        }
        try
        {
            StartProgress(Report.Slices.Count);
            _globalTotalValue = 0.0;
            await _sliceService.ProcessSlices(Report.Model, _cancellationTokenSource.Token);
            _areSlicesProcessed = true;
            StopProgress(false);
        }
        catch (OperationCanceledException)
        {
            StopProgress(true);
        }
        catch (Exception ex)
        {
            StopProgress(true);
            ShowError(ex);
        }
    }

    private void SliceService_SliceProcessed(Slice slice)
    {
        Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Send, () =>
        {
            slice.InvokeUpdate();
            var reportModel = Report.Model;

            if ((slice.MinValue?.Value ?? int.MaxValue) < (reportModel.GlobalMinValue.Value ?? int.MaxValue))
            {
                reportModel.GlobalMinValue.ZPosition = slice.ZPosition;
                reportModel.GlobalMinValue.Value = slice.MinValue?.Value ?? 0;
                reportModel.GlobalMinValue.InvokeUpdate();
            }
            if ((slice.MaxValue?.Value ?? int.MinValue) > (reportModel.GlobalMaxValue.Value ?? int.MinValue))
            {
                reportModel.GlobalMaxValue.ZPosition = slice.ZPosition;
                reportModel.GlobalMaxValue.Value = slice.MaxValue?.Value ?? 0;
                reportModel.GlobalMaxValue.InvokeUpdate();
            }
            CurrentProgress++;

            _globalTotalValue += slice.AvgValue ?? 0.0;
            double avgValue = Math.Round(_globalTotalValue / CurrentProgress, 2);
            if (reportModel.GlobalAvgValue != avgValue)
            {
                reportModel.GlobalAvgValue = avgValue;
                reportModel.InvokeUpdate();
            }
        });
    }

    [RelayCommand]
    private async Task LoadReport()
    {
        try
        {
            var openFileDialog = new OpenFileDialog();
            openFileDialog.Title = ReportDialogTitle;
            openFileDialog.Filter = ReportDialogFilter;
            if (openFileDialog.ShowDialog() == true)
            {
                StartProgress();
                ProgressText = "Loading...";
                Report = new ReportViewModel(await _reportService.LoadReport(openFileDialog.FileName, _cancellationTokenSource.Token));
                _isReportLoaded = true;
                StopProgress(false);
                ProgressText = $"Loaded ({Report.Slices.Count}/{Report.Slices.Count})";
            }
        }
        catch (OperationCanceledException)
        {
            StopProgress(true);
        }
        catch (Exception ex)
        {
            StopProgress(true);
            ShowError(ex);
        }
    }

    [RelayCommand]
    private async Task SaveReport()
    {
        if (Report.Slices.Count == 0)
        {
            ShowError("Slices have not been loaded.\n\nPlease load and process them before saving the report.");
            return;
        }
        if (!_isReportLoaded && !_areSlicesLoaded && !ShowWarning("Slices have not been completely loaded.\n\nDo you want to save the report?"))
        {
            return;
        }
        if (!_isReportLoaded && !_areSlicesProcessed && !ShowWarning("Slices have not been completely processed.\n\nDo you want to save the report?"))
        {
            return;
        }
        try
        {
            var saveFileDialog = new SaveFileDialog();
            saveFileDialog.Title = ReportDialogTitle;
            saveFileDialog.Filter = ReportDialogFilter;
            if (saveFileDialog.ShowDialog() == true)
            {
                StartProgress();
                ProgressText = "Saving...";
                await _reportService.SaveReport(saveFileDialog.FileName, Report.Model, _cancellationTokenSource.Token);
                StopProgress(false);
                ProgressText = "Saved";
            }
        }
        catch (OperationCanceledException)
        {
            StopProgress(true);
        }
        catch (Exception ex)
        {
            StopProgress(true);
            ShowError(ex);
        }
    }

    [RelayCommand]
    private void Cancel()
    {
        _cancellationTokenSource?.Cancel();
    }

    private void StartProgress(int? maxProgress = null)
    {
        _cancellationTokenSource = new CancellationTokenSource();
        if (maxProgress != null)
        {
            MaxProgress = maxProgress.Value;
            CurrentProgress = 0;
            IsProgressBarVisible = true;
        }
        else
        {
            IsProgressBarVisible = false;
        }
        IsProgressTextVisible = true;
        IsMenuEnabled = false;
        IsCancelEnabled = true;
        _stopWatch.Restart();
    }

    private void StopProgress(bool isError)
    {
        IsMenuEnabled = true;
        IsCancelEnabled = false;
        if (!isError && !_cancellationTokenSource.IsCancellationRequested)
        {
            IsProgressBarVisible = false;
        }
        _cancellationTokenSource = null;
        _stopWatch.Stop();
    }

    partial void OnCurrentProgressChanged(int value)
    {
        ProgressText = $"{CurrentProgress}/{MaxProgress} ({_stopWatch.Elapsed:ss\\.fff} seconds)";
    }

    private static bool ShowWarning(string text)
    {
        return MessageBox.Show(text, "Warning", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;
    }

    private static void ShowError(string message)
    {
        ShowError(new Exception(message));
    }

    private static void ShowError(Exception ex)
    {
        MessageBox.Show(ex.ToShortString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
    }
}
