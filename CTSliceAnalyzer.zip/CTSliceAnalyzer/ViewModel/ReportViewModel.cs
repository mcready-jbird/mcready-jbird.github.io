﻿using CommunityToolkit.Mvvm.ComponentModel;
using CTSliceAnalyzer.Model;
using System.Collections.ObjectModel;

namespace CTSliceAnalyzer.ViewModel;

public partial class ReportViewModel : ObservableObject
{
    Report _report;

    [ObservableProperty]
    private GlobalValueViewModel? _globalMinValue;

    [ObservableProperty]
    private GlobalValueViewModel? _globalMaxValue;

    [ObservableProperty]
    private double? _globalAvgValue;

    public ObservableCollection<SliceViewModel> Slices { get; set; } = [];

    public Report Model => _report;

    public ReportViewModel(Report report)
    {
        _report = report;

        GlobalMinValue = new GlobalValueViewModel(report.GlobalMinValue);
        GlobalMaxValue = new GlobalValueViewModel(report.GlobalMaxValue);
        GlobalAvgValue = report.GlobalAvgValue;
        foreach (var slice in report.Slices)
        {
            Slices.Add(new SliceViewModel(slice));
        }

        report.Update = () =>
        {
            GlobalAvgValue = report.GlobalAvgValue;
        };
    }

    public void AddSlice(Slice slice)
    {
        _report.Slices.Add(slice);
        Slices.Add(new SliceViewModel(slice));
    }
}
