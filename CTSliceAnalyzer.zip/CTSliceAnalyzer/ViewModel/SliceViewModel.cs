﻿using CommunityToolkit.Mvvm.ComponentModel;
using CTSliceAnalyzer.Model;

namespace CTSliceAnalyzer.ViewModel;

public partial class SliceViewModel : ObservableObject
{
    [ObservableProperty]
    private double _zPosition;

    [ObservableProperty]
    private string? _dimensions;

    [ObservableProperty]
    private string? _minValue;

    [ObservableProperty]
    private string? _maxValue;

    [ObservableProperty]
    private double? _avgValue;

    public SliceViewModel(Slice slice)
    {
        ZPosition = slice.ZPosition;
        Dimensions = $"{slice.Dimensions.Width} x {slice.Dimensions.Height}";
        UpdateValues(slice);

        slice.Update = () =>
        {
            UpdateValues(slice);
        };
    }

    private void UpdateValues(Slice slice)
    {
        MinValue = slice.MinValue == null ? String.Empty : $"{slice.MinValue?.Value} ({slice.MinValue?.X} x {slice.MinValue?.Y})";
        MaxValue = slice.MaxValue == null ? String.Empty : $"{slice.MaxValue?.Value} ({slice.MaxValue?.X} x {slice.MaxValue?.Y})";
        AvgValue = slice.AvgValue;
    }
}