﻿using CTSliceAnalyzer.Model;

namespace CTSliceAnalyzer.Services;

public interface IReportService
{
    Task<Report> LoadReport(string filePath, CancellationToken cancellationToken);

    Task SaveReport(string filePath, Report report, CancellationToken cancellationToken);
}
