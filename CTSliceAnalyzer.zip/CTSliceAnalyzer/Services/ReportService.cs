﻿using CTSliceAnalyzer.Model;
using System.IO;
using System.Text.Json;

namespace CTSliceAnalyzer.Services;

public class ReportService : IReportService
{
    public async Task<Report> LoadReport(string filePath, CancellationToken cancellationToken)
    {
        try
        {
            string json = await File.ReadAllTextAsync(filePath, cancellationToken);
            var report = JsonSerializer.Deserialize<Report>(json);
            if (report == null)
            {
                throw new Exception("Error deserialization json");
            }
            return report;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error loading report {filePath}", ex);
        }
    }

    public async Task SaveReport(string filePath, Report report, CancellationToken cancellationToken)
    {
        try
        {
            string json = JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true });
            await File.WriteAllTextAsync(filePath, json, cancellationToken);
        }
        catch (OperationCanceledException)
        {
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
        }
        catch (Exception ex)
        {
            throw new Exception($"Error saving report {filePath}", ex);
        }
    }
}
