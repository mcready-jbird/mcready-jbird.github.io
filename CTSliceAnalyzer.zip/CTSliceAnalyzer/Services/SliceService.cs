﻿using CTSliceAnalyzer.Global;
using CTSliceAnalyzer.Model;
using System.IO;

namespace CTSliceAnalyzer.Services;

public class SliceService : ISliceService
{
    public event Action<Slice>? Loaded;

    public event Action<Slice>? Processed;

    public async Task LoadSlices(IEnumerable<string> fileNames, CancellationToken cancellationToken)
    {
        foreach (var fileName in fileNames)
        {
            try
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return;
                }
                using var reader = new StreamReader(fileName);
                var zPositionString = await reader.ReadLineAsync(cancellationToken);
                if (!double.TryParse(zPositionString, NumberFormatSettings.NumberFormatInfo, out double zPosition))
                {
                    throw new Exception("Incorrect Z position");
                }
                var dimensionString = await reader.ReadLineAsync(cancellationToken);
                var dimensions = dimensionString?.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (dimensions?.Length != 2)
                {
                    throw new Exception("Incorrect dimensions");
                }
                if (!int.TryParse(dimensions[0], out var width))
                {
                    throw new Exception("Incorrect width");
                }
                if (!int.TryParse(dimensions[1], out var height))
                {
                    throw new Exception("Incorrect height");
                }
                var rawData = await reader.ReadLineAsync(cancellationToken);
                if (String.IsNullOrEmpty(rawData))
                {
                    throw new Exception("No values found");
                }
                var slice = new Slice()
                {
                    FileName = fileName,
                    RawData = rawData,
                    ZPosition = Math.Round(zPosition, 12),
                    Dimensions = new Dimensions(width, height)
                };
                Loaded?.Invoke(slice);
            }
            catch (OperationCanceledException)
            {
            }
            catch (Exception ex)
            {
                throw new Exception($"Error loading file {fileName}", ex);
            }
        }
    }

    public async Task ProcessSlices(Report report, CancellationToken cancellationToken)
    {
        var options = new ParallelOptions
        {
            MaxDegreeOfParallelism = Environment.ProcessorCount,
            CancellationToken = cancellationToken
        };
        await Parallel.ForEachAsync(report.Slices, options, ProcessSlice);
    }

    private ValueTask ProcessSlice(Slice slice, CancellationToken cancellationToken)
    {
        try
        {
            if (slice.RawData == null)
            {
                return ValueTask.CompletedTask;
            }
            var values = slice.RawData.Split(' ', StringSplitOptions.RemoveEmptyEntries) ?? [];
            if (values.Length != slice.Dimensions.Width * slice.Dimensions.Height)
            {
                throw new Exception($"Incorrect amount of values {values.Length}");
            }
            var minValue = new SliceValue(int.MaxValue);
            var maxValue = new SliceValue(int.MinValue);
            double avgValue = 0.0;
            for (int y = 0; y < slice.Dimensions.Height; y++)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return ValueTask.CompletedTask;
                }
                for (int x = 0; x < slice.Dimensions.Width; x++)
                {
                    string? valueString = values[y * slice.Dimensions.Width + x];
                    if (!int.TryParse(valueString, out int value))
                    {
                        throw new Exception($"Incorrect value ({valueString})");
                    }
                    if (value < minValue.Value)
                    {
                        minValue = new SliceValue(value, x, y);
                    }
                    if (value > maxValue.Value)
                    {
                        maxValue = new SliceValue(value, x, y);
                    }
                    avgValue += (double)value / values.Length;
                }
            }
            slice.MinValue = minValue;
            slice.MaxValue = maxValue;
            slice.AvgValue = avgValue;
            Processed?.Invoke(slice);

            return ValueTask.CompletedTask;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error processing slice {slice.FileName}", ex);
        }
    }
}
