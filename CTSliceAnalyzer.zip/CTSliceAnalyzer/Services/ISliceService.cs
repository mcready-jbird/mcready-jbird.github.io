﻿using CTSliceAnalyzer.Model;

namespace CTSliceAnalyzer.Services;

public interface ISliceService
{
    event Action<Slice> Loaded;

    event Action<Slice> Processed;

    Task LoadSlices(IEnumerable<string> fileNames, CancellationToken cancellationToken);

    Task ProcessSlices(Report report, CancellationToken cancellationToken);
}
