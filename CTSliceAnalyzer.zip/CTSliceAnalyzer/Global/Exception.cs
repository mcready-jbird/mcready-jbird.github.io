﻿using System.Text;

namespace CTSliceAnalyzer.Global;

public static class ExceptionExtensions
{
    public static string ToShortString(this Exception? ex)
    {
        var sb = new StringBuilder();
        int lineCount = 0;
        while (ex != null)
        {
            if (lineCount > 0)
            {
                sb.Append($"{new string('-', lineCount)}>");
            }
            sb.AppendLine(ex.Message);
            ex = ex.InnerException;
            lineCount++;
        }
        return sb.ToString();
    }
}
