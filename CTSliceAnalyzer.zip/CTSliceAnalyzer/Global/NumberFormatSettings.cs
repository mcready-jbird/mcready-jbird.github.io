﻿using System.Globalization;

namespace CTSliceAnalyzer.Global;

public static class NumberFormatSettings
{
    public static readonly NumberFormatInfo NumberFormatInfo = new() { NumberDecimalSeparator = "." };
}
