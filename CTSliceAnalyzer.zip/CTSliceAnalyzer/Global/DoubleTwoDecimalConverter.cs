﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace CTSliceAnalyzer.Global;

public class DoubleTwoDecimalConverter : JsonConverter<double?>
{
    public override double? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType == JsonTokenType.Null)
            return null;

        return reader.GetDouble();
    }

    public override void Write(Utf8JsonWriter writer, double? value, JsonSerializerOptions options)
    {
        if (value.HasValue)
        {
            writer.WriteNumberValue(Math.Round(value.Value, 2));
        }
        else
        {
            writer.WriteNullValue();
        }
    }
}