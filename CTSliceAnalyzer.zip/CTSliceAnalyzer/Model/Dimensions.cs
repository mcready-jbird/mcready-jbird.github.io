﻿using System.Text.Json.Serialization;

namespace CTSliceAnalyzer.Model;

[method: JsonConstructor]
public readonly struct Dimensions(int width, int height)
{
    [JsonPropertyName("width")]
    public int Width { get; } = width;

    [JsonPropertyName("height")]
    public int Height { get; } = height;
}
