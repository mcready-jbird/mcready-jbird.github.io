﻿using System.Text.Json.Serialization;

namespace CTSliceAnalyzer.Model;

public class GlobalValue
{
    public Action? Update;

    [JsonPropertyName("z_pos")]
    public double? ZPosition { get; set; }

    [JsonPropertyName("value")]
    public int? Value { get; set; }

    public void InvokeUpdate()
    {
        Update?.Invoke();
    }
}
