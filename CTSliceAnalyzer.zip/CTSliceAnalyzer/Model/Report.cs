﻿using CTSliceAnalyzer.Global;
using System.Text.Json.Serialization;

namespace CTSliceAnalyzer.Model;

public class Report
{
    public Action? Update;

    [JsonPropertyName("global_min")]
    public GlobalValue GlobalMinValue { get; set; } = new GlobalValue();

    [JsonPropertyName("global_max")]
    public GlobalValue GlobalMaxValue { get; set; } = new GlobalValue();

    [JsonPropertyName("global_avg")]
    public double? GlobalAvgValue { get; set; }

    [JsonPropertyName("slices")]
    public List<Slice> Slices { get; set; } = [];

    public void InvokeUpdate()
    {
        Update?.Invoke();
    }
}
