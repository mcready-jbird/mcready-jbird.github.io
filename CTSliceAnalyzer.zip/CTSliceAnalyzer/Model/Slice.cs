﻿using CTSliceAnalyzer.Global;
using System.Text.Json.Serialization;

namespace CTSliceAnalyzer.Model;

public class Slice
{
    public Action? Update;

    [JsonIgnore]
    public string? FileName { get; set; }

    [JsonIgnore]
    public string? RawData { get; set; }

    [JsonPropertyName("z_pos")]
    public double ZPosition { get; set; }

    [JsonPropertyName("dim")]
    public Dimensions Dimensions { get; set; }

    [JsonPropertyName("min")]
    public SliceValue? MinValue { get; set; }

    [JsonPropertyName("max")]
    public SliceValue? MaxValue { get; set; }

    [JsonPropertyName("avg")]
    [JsonConverter(typeof(DoubleTwoDecimalConverter))]
    public double? AvgValue { get; set; }

    public void InvokeUpdate()
    {
        Update?.Invoke();
    }
}
