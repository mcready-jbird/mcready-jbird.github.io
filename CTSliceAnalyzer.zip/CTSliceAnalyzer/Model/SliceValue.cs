﻿using System.Text.Json.Serialization;

namespace CTSliceAnalyzer.Model;

[method: JsonConstructor]
public readonly struct SliceValue(int value, int x = 0, int y = 0)
{
    [JsonPropertyName("value")]
    public int Value { get; } = value;

    [JsonPropertyName("x")]
    public int X { get; } = x;

    [JsonPropertyName("y")]
    public int Y { get; } = y;
}
